import { useContext } from "react";
import { JokeContext } from "../context/JokeContext";

const JokeCard = ({ joke }) => {
    const { likeJoke, dislikeJoke } = useContext(JokeContext);

    // Joke copy karne ka function
    const copyToClipboard = () => {
        const jokeText = joke.setup ? `${joke.setup} ${joke.delivery}` : joke.joke;
        navigator.clipboard.writeText(jokeText);
        alert("Joke copied to clipboard!");
    };

    return (
        <div style={{ border: "1px solid black", padding: "10px", margin: "10px" }}>
            <p>{joke.setup ? `${joke.setup} ${joke.delivery}` : joke.joke}</p>
            <button onClick={() => likeJoke(joke)}>Like</button>
            <button onClick={() => dislikeJoke(joke.id)}>Dislike</button>
            <button onClick={copyToClipboard}>Copy</button>
        </div>
    );
};

export default JokeCard;
