import { Link } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Navbar = () => {
    const { user, logout } = useContext(AuthContext);

    return (
        <nav>
            <Link to="/dashboard">Home</Link>
            <Link to="/saved-jokes">Saved Jokes</Link>
            {!user ? (
                <>
                    <Link to="/login">Login</Link>
                    <Link to="/signup">Signup</Link>
                </>
            ) : (
                <button onClick={logout}>Logout</button>
            )}
        </nav>
    );
};

export default Navbar;
