import { useContext, useState } from "react";
import { JokeContext } from "../context/JokeContext";
import JokeCard from "../components/JokeCard";

const Dashboard = () => {
    const { jokes, fetchJokes } = useContext(JokeContext);
    const [searchTerm, setSearchTerm] = useState("");
    const [category, setCategory] = useState("Any");

    // Search + Category Filter
    const filteredJokes = jokes.filter(joke => 
        (category === "Any" || joke.category === category) &&
        (joke.joke?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        joke.setup?.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    // Category change karne par API se naya data fetch karna
    const handleCategoryChange = async (e) => {
        const selectedCategory = e.target.value;
        setCategory(selectedCategory);

        let apiUrl = "https://v2.jokeapi.dev/joke/";
        apiUrl += selectedCategory === "Any" ? "Any" : selectedCategory;
        apiUrl += "?amount=10";

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();
            fetchJokes(data.jokes);
        } catch (error) {
            console.error("Error fetching category jokes:", error);
        }
    };

    return (
        <div>
            <h2>Jokes Dashboard</h2>

            <input 
                type="text" 
                placeholder="Search Jokes..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)} 
            />

            <select value={category} onChange={handleCategoryChange}>
                <option value="Any">All Categories</option>
                <option value="Programming">Programming</option>
                <option value="Dark">Dark</option>
                <option value="Pun">Pun</option>
                <option value="Spooky">Spooky</option>
                <option value="Christmas">Christmas</option>
            </select>

            <button onClick={fetchJokes}>Reload Jokes</button>

            {filteredJokes.length === 0 ? (
                <p>No jokes found.</p>
            ) : (
                filteredJokes.map((joke, index) => <JokeCard key={index} joke={joke} />)
            )}
        </div>
    );
};

export default Dashboard;
