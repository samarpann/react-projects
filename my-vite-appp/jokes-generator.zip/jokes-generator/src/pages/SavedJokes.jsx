import { useContext } from "react";
import { JokeContext } from "../context/JokeContext";
import JokeCard from "../components/JokeCard";

const SavedJokes = () => {
    const { likedJokes } = useContext(JokeContext);

    return (
        <div>
            <h2>Saved Jokes</h2>
            {likedJokes.length === 0 ? (
                <p>No saved jokes yet.</p>
            ) : (
                likedJokes.map((joke, index) => <JokeCard key={index} joke={joke} />)
            )}
        </div>
    );
};

export default SavedJokes;
